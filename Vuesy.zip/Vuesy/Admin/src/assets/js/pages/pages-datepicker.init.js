
/*
Template Name: Vuesy - Admin & Dashboard Template
Author: Themesdesign
Website: https://Themesdesign.in/
Contact: themesdesign.in@gmail.com
File: pages datepicker Init Js File
*/

flatpickr('#datepicker-range', {
    mode: "range"
});